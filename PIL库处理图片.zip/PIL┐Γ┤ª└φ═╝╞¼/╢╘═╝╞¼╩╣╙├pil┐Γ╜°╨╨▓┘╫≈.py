#引入PIL库
from PIL import Image
im=Image.open('example.jpg')
print(im)
im.resize(1000)
print(im)
