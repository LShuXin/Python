#-*-coding：utf-8-*-
# 理论
# web原理
#url 全景求资源统一定位符
# web框架
#    固定的底层的
#    若干框架
#    djanggo（大企业使用） tornodo falsk
#
# tornado框架 轻量级、高并发、facebook
import tornado
from tornado import web,ioloop,httpserver
class Main
web.Application