# -*- coding:utf-8 -*-
import cv2, time, serial
import numpy as np

cap = cv2.VideoCapture(0)
font = cv2.FONT_HERSHEY_SIMPLEX #del
#ser = serial.Serial("COM5",9600)
while True:
    a = time.time()
    ret, frame = cap.read()
    hvs = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    low_red = np.array([0,100,120]) #颜色 饱和度 亮度 方案1 0 0 100 方案2 0 0 100
    high_red = np.array([20,200,255]) #颜色 饱和度 亮度 方案1 120 50 255 方案2 60 50 255
    mask = cv2.inRange(hvs, low_red, high_red)
    ck = []
    for gs in range(10,640,10):
        ck.append(mask[:,gs-10:gs].sum())
        cv2.line(mask, (gs, 0), (gs, 480), (255, 0, 0), 1) #del
        best = ck.index(max(ck))
    cv2.putText(mask, "Y", (best * 10, 440), font, 1, (255, 0, 0), 2) #del
    cv2.imshow("frame", frame) #显示图像 del
    cv2.imshow("mask", mask) #显示图像 del
    if max(ck) > 140000:
       # ser.write(chr(best).encode("utf-8"))
        print(best)
    else:
        pass
        #ser.write(chr(90).encode("utf-8"))

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


cap.release()
cv2.destroyAllWindows()