# pip install xlwt
# pip install
# 带星号列的参数需要手动修改
import xlrd;
import xlwt;
class Params:
    def __init__(self):
        self.traveltimescol=32;# 出行次数字段所在的列（从1开始计数，手动修改 ***********************）
        self.travelinfonum=11;# 每条“出行”信息包含的字段数（需手动修改*****************************）
        self.numrecords=0;#一共有多少条记录，无需手动修改
        self.numattribute=315#每条记录一共有多少个字段，无需手动修改
        self.traveltimes=0;#当前出行者当日出行的次数，无需手动修改
        self.tabnmstart="F:\交通工程\OD调查\表1-12018年山东理工大学学生出行调查表.xls";#待处理的文件路径，包含最终文件以及文件的扩展名*******************）
        self.tabnmend="F:\交通工程\OD调查\demotest0.xls";#处理结果文件要保存的路径以及最后要保存的文件名，带后缀****************************************）
p=Params();
i = 0;#记录遍历变量
j = 1;#记录填写行记录变量
# ctype=2;
data="";
traleln=0;
n=0;
z=0;
k=0;
# 打开表格
tbstart=xlrd.open_workbook(r'C:\Users\Administrator\Desktop\OD调查\处理前\表1-1   2018年山东理工大学学生出行调查表_960_830.xls').sheets()[0] ;
workbook = xlwt.Workbook(encoding = 'ascii');
worksheet = workbook.add_sheet('My Worksheet',cell_overwrite_ok=True);
# 获取行和列
p.numrecords = tbstart.nrows;  # 查询一共有多少条记录
p.numattribute = tbstart.ncols  # 查询一条记录共有多少个字段
# 在新表中填写标题
# print(tbstart.cell_value(0, 141))
#复制标题，标题全部为字符串
for i in range(0,int(p.traveltimescol+p.travelinfonum)):
    worksheet.write(0, i, str(tbstart.cell_value(0, i)));
for i in range(1,p.numrecords): # 遍历原表记录
    traveln=tbstart.cell_value(i, p.traveltimescol-1);  #个人出行的次数
    for m in range(0,int(p.traveltimescol+p.travelinfonum-1)): # 一次出行记录以及以前的数据
        if tbstart.cell(i, m).ctype==2:
            data=int(tbstart.cell_value(i, m));
        else:
            data=str(tbstart.cell_value(i, m));
        if tbstart.cell_value(i, m)==-3: #如果数据类型为数值型并且值为-3，则数据为空
            data="";
        worksheet.write(j,m,data);



    #填写其他次数的出行记录
    if (traveln==0)or(traveln==1):#如果出行了零次或者一次，那么直接跳出
        j=j+1;
        continue;
    else:
        for n in range(1,int(int(traveln)+1)):
            k = p.traveltimescol;
            j = j + 1;#行数加一
            for z in range(p.traveltimescol+n*p.travelinfonum,p.traveltimescol+(n+1)*p.travelinfonum):
                data = str(tbstart.cell_value(i, z));
                if tbstart.cell(i, z).ctype == 2 and tbstart.cell_value(i, z) == -3: # 如果数据类型为数值型并且值为-3，则数据为空
                    data = "";
                worksheet.write(j, k, str(data));
                k=k+1;



workbook.save('F:\表1-1.xls')

