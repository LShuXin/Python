import cv2, time
import numpy as np

def first(frame):
    return frame[:,:,2]

def second(frame):
    AGB = frame[:,:,0:1]


cap = cv2.VideoCapture(0)
font = cv2.FONT_HERSHEY_SIMPLEX
while True:
    a = time.time()
    ret, frame = cap.read()
    PD = first(frame)
    ck = []
    frame[:, :, 0:1] = 0
    cv2.imshow("1e", frame)
    for gs in [64,128,192,256,320,384,448,512,576,640]:
        ck.append(PD[:,gs-64:gs].sum())
        cv2.line(frame, (gs, 0), (gs, 480), (255, 0, 0), 2)
        cv2.putText(frame, str(int(gs/64)), (gs-42,40),font,1, (255,0,0),2)
    cv2.putText(frame, "Y", (ck.index(max(ck))*64+20, 440), font, 1, (255, 0, 0), 2)
    cv2.imshow("capture", frame)
    print(ck.index(max(ck)))

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


cap.release()
cv2.destroyAllWindows()