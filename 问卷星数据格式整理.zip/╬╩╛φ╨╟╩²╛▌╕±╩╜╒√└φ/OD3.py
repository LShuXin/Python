# pip install xlwt
# pip install
# 使用需修改部分参数
import xlrd;
import xlwt;
class Params:
    def __init__(self):
        # *************************************************************************************参数修改****************************************************************************
        self.traveltimescol=23;# 出行次数字段所在的列（从1开始计数）
        self.travelinfonum=11;# 一次“出行”信息包含的字段数
        self.tabnmstart = "F:\交通工程\OD调查\表1-12018年山东理工大学学生出行调查表.xls";  # 待处理的文件 如："F:\交通工程\OD调查\表1-12018年山东理工大学学生出行调查表.xls"
        self.tabnmend = "F:\交通工程\OD调查\demotest0.xls";  # 处理结果文件要保存的结果如："F:\交通工程\OD调查\demotest0.xls";
        # *************************************************************************************参数修改****************************************************************************
        self.numrecords=0;#原表记录总数
        self.numattribute=0;#每条记录字段数
        self.traveltimes=0;#当日出行次数
# 实例化参数对象
p=Params();
i = 0;#记录查阅行遍历变量
j = 1;#记录填写行计数变量
data="";#写数据预存变量
n=0;#出行次数遍历
z=0;#数据写入列
k=0;
# 打开表格
tbstart=xlrd.open_workbook(r'C:\Users\Administrator\Desktop\OD调查\处理前\表1-2    2018年山东理工大学教职工出行调查表.xls').sheets()[0] ;
workbook = xlwt.Workbook(encoding = 'ascii');
worksheet = workbook.add_sheet('My Worksheet',cell_overwrite_ok=True);
# 获取行和列数
p.numrecords = tbstart.nrows;  # 查询一共有多少条记录
p.numattribute = tbstart.ncols  # 查询一条记录共有多少个字段
# 在新表中填写标题标题
for i in range(0,int(p.traveltimescol+p.travelinfonum)):
    if i>=p.traveltimescol:
        if i==p.traveltimescol:
            worksheet.write(0, i, '出行次序');
        travellist=i+1;
        worksheet.write(0, travellist, tbstart.cell_value(0, i));
    else:
        worksheet.write(0, i, tbstart.cell_value(0, i));
# 遍历旧表
for i in range(1,p.numrecords):
    traveln=tbstart.cell_value(i, p.traveltimescol-1);  #个人出行的次数
    for m in range(0,int(p.traveltimescol+p.travelinfonum)): # 写入一次出行记录以及以前的数据
        if tbstart.cell(i, m).ctype==2:
            data=int(tbstart.cell_value(i, m));
        else:
            data=tbstart.cell_value(i, m);
        # 如果数据类型为数值型并且值为-3，则数据为空
        if tbstart.cell_value(i, m)==-3:
            data="";
        if m>=p.traveltimescol:
            worksheet.write(j, m+1, data);
        else:
           worksheet.write(j,m,data);
        worksheet.write(j, p.traveltimescol, 1);
    #填写其他次数的出行记录
    if (traveln==0)or(traveln==1):#如果出行了零次或者一次，那么直接跳出
        j=j+1;
        continue;
    else:
        for n in range(1,int(int(traveln)+1)):
            k = p.traveltimescol+1;
            j = j + 1;#行数加一
            for z in range(p.traveltimescol+n*p.travelinfonum,p.traveltimescol+(n+1)*p.travelinfonum):
                data = tbstart.cell_value(i, z);
                if tbstart.cell(i, z).ctype == 2 and tbstart.cell_value(i, z) == -3: # 如果数据类型为数值型并且值为-3，则数据为空
                    data = "";
                worksheet.write(j, k, data);
                k=k+1;
            worksheet.write(j, p.traveltimescol, n + 1);
workbook.save('F:\表1-2.xls')

