#!/usr/bin/python3
import re
mail= ["mail.bccto.me", "bccto.me", "www.bccto.me", "3202.com",
       "chaichuang.com", "opmmail.com", "819110.com", "evcmail.com",
       "fxfmail.com", "899079.com", "4057.com", "sltmail.com", "pincoffee.com",
       "120mail.com", "czpanda.cn", "dawin.com", "114207.com", "yxir.cn",
       "fremail.club", "60950.cn", "xuyushuai.com"]

def judge(x):
    flag=0 #假设不在范围内
    for i in mail:
        regexp=re.compile('('+i+')$')
        if(re.findall(regexp,x)):
            flag=1
            break
    if (flag):
        str="{}:在过滤范围之内".format(x)+'\n'
        print(str)
    else:
        str="{}:不在过滤范围之内".format(x)+'\n'
        print(str)
    return str





# def judge(x):
#     flag = 0
#     length = len(x)
#     for i in range(len(mail)):
#         res=re.split(r'@',x)
#         print(res[-1])
#         if(res[-1]==mail[i]):
#             flag=1
#             break;
#     if(flag):
#         print("{}:在过滤范围之内".format(x))
#     else:
#         print("{}:不在过滤范围之内".format(x))