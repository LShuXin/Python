#!/usr/bin/python3

import judge
import time
tf = open("simple mail filter.txt","rt",encoding='utf-8')
resfile_name=time.time()
resfile=open(str(resfile_name)+".txt","wt",encoding='utf-8')
for line in tf.readlines():
    x = line[0:-1]
    res=judge.judge(x)
    resfile.write(res)
tf.close()
resfile.close()


# while True:
#     x = input("输入要判断的邮箱(输入0结束程序)：")
#
#     if(x=='0'):
#         break
#     else:
#         judge.judge(x)


