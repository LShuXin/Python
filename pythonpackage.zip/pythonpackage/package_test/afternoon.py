# -*- coding: UTF-8 -*-
def greet_aternoon(name):
    print("Good Afternoon:"+name);
def time_now_print():
    print("this is afternoon");