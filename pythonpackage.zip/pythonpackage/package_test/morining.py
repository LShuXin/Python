# -*- coding: UTF-8 -*-
def greet_morning(name):
    print("Good Morning:"+name);
def time_now_print():
    print("this is moring");