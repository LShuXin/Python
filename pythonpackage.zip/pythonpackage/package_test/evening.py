# -*- coding: UTF-8 -*-
def greet_evening(name):
    print("Good Evening:"+name);
def time_now_print():
    print("this is evening");