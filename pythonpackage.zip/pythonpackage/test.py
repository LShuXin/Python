# -*- coding: UTF-8 -*-
from package_test.morining import greet_morning
greet_morning("shi")