class ShortInputException(Exception):
    #自定义类，这个类在实例化的时候接受一个字符串作为参数
    #该类分别有两个属性，length与atleast
    def __init__(self, length, atleast):
        Exception.__init__(self)
        self.length = length  #类的第一个属性，字符串的长度
        self.atleast = atleast#自定义类的第二个属性
#自定义类的异常
try:
    s = input('请输入一个字符串：')
    if len(s) < 3:
        raise ShortInputException(len(s), 3)
    else:
        print(s)
except EOFError:
    print('\n输入为EOF，结束！')
except ShortInputException as x:
    print('ShortInputException:The input was length{} ,was expecting at least {}.'.format(x.length, x.atleast))
else:
    print('No exception was raised.')
