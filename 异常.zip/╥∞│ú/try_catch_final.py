try:
    x=int(input("输入第一个数字："))
    y=int(input("输入第二个数字："))
    print(x/y)
except(ZeroDivisionError,ValueError) as e:
    print(e)
    print("请检查输入的参数！")
finally:
    print("game over!")

